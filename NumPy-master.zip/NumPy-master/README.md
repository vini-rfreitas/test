# NumPy

Jupyter Notebook &amp; Data Associated with my Tutorial video on the Python NumPy Library

Video Link:
https://youtu.be/GB9ByFAIAH4
